<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Swimming Pool Blog</title>
	<meta name="description" content="Swimming pool blogs, information about diffrent methos of how we clean the tiles from your pool">
	<meta name="author" content="SacPoolPros">

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="img/favicon.ico">
	<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">

	<!-- CSS Template
	================================================== -->
	<link rel="stylesheet" href="css/template-1.css">
	
</head>
<body>
<div class="loading"><div class="over-pattern diagonal opacity20"></div><span>Loading...</span></div>

	<!-- Start - Used on #to-top click -->
	<div id="start"></div>

	<div id="top">
		<div class="container">
			<div class="four columns clearfix">
				<div class="logo"><a href="./"><img src="img/style1/logo-stone.png" alt="Stone" width="143" height="40" /></a></div>
				<!-- Mobile Menu -->
				<nav id="mobile-top-menu">
					<a href="#" class="mobile-nav-button"><i class="fa fa-bars"></i></a>
					<div id="menu-list"><div id="menu-content"></div></div>
				</nav>
			</div>

			<div class="twelve columns">
				<!-- Main Menu -->
				<?php include("include/topnav.php");?>
	<!-- Don't remove #top-space! -->
	<div id="top-space"></div>
	<!-- Don't remove #top-space! -->
	
	<!-- #Project Page -->
	<section id="project" class="page nopaddingbottom">
		<!-- #Breadcrumbs -->
		<div id="breadcrumbs">
			<div class="container">
				<div class="sixteen columns">
					<p><a href="index.php#portfolio">Blog</a> <i class="fa fa-angle-double-right"></i> <span>Project Details</span></p>
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<h1 class="super-title"><span class="color1">#</span>Tile Cleaning</h1>
				</div>
			</div>

			<div class="row sidebar">
				<!-- Client Informations -->
				<div class="four columns">
					<div class="row">
						<h3 class="sidebar-title">Category</h3>
						<p>Service</p>
					</div>
					<div class="row">
						<h3 class="sidebar-title">What we do</h3>
						<ul class="list">
							<li><i class="fa fa-angle-right"></i>San Blast</li>
							<li><i class="fa fa-angle-right"></i>Grout Cleaning</li>
							<li><i class="fa fa-angle-right"></i>Buildup Removal</li>
							<li><i class="fa fa-angle-right"></i>Tile Inspection</li>
						</ul>
					</div>
					<div class="row">
						
					</div>
				</div>

				<!-- Owl Carousel Photo Slider -->			
				<div class="twelve columns">
					<div id="owl-slider" class="owl-carousel">
						<div class="item"><figure><img src="img/tile/photo 1.JPG" alt="Pumps"></figure></div>
                        <div class="item"><figure><img src="img/tile/photo 2.JPG" alt="Pumps"></figure></div>
                        <div class="item"><figure><img src="img/tile/photo 3.JPG" alt="Pumps"></figure></div>
                        <div class="item"><figure><img src="img/tile/photo 4.JPG" alt="Pumps"></figure></div>
                        <div class="item"><figure><img src="img/tile/photo 5.JPG" alt="Pumps"></figure></div>
						
					</div>
				</div>
			</div>

			<!-- Project Informations -->
			<div class="row">
				<div class="sixteen columns">
					<h2 class="title">About Tile Cleaning...</h2>
<p>In Sacramento, CA we have really hard water, which I&rsquo;m sure  if you&rsquo;re reading this you have noticed here at Sac Pool Pros we specialize in  making your calcium deposit problems stress free you may notice that your  pretty bright blue tiles are covered in white ugly scale and it just makes your  pool not look attractive any more or you may have a white ring around your pool  well first off I want to tell you that you don&rsquo;t have to pay thousands of  dollars to replace your swimming pool tile because even if you do replace your  swimming pool tile the white build up will be back in 2-3 years you can restore  your current pool tile and save tons of money in the process at Sac Pool Pros  we are here to help our process is very easy and simple </p>
<ol>
  <li>We drain your swimming pool below the water line  around 4-6 inches to create a nice clean work space </li>
  <li>We will then set up to blast your tile with our  tow behind diesel air compressor we shoot glass beads or soda depending on the  tile at around 80 PSI which is just enough to eat the calcium off your tile  this will NOT damage your tile it will actually polish and make your tiles  shine as the first day they were installed </li>
  <li>After we are finished cleaning your tile we will  then vacuum all of the media out of the pool with a portable vacuum and hose  off the swimming pool deck and surrounding areas  </li>
  <li>Last but not least we will use a sealer on your  tile that helps protect your tile from future build ups and makes them clean  and shinny again! </li>
</ol>
<p>&nbsp;</p>

<p><strong>
  Gives us a call today for a estimate! <br> 
David Randolph<br>
(530)312-2614</strong>
</p>
			  </div>
			</div>
		</div>
		
		<!-- Prev or Next Project
		<div class="buttons-block">
			<div class="container">
				<div class="sixteen columns">
					<a href="#" class="btn small disabled"><i class="fa fa-angle-left"></i> Previous Project</a>
					<a href="#" class="btn small color2">Previous Project <i class="fa fa-angle-right right"></i></a>
				</div>
			</div>
		</div> -->		
	</section>

	<!-- #Footer -->
	<section id="footer" class="pattern diagonal clearfix">
		<div class="shadow"></div>
		<div class="container">
			<div class="row">
				<!-- Logo -->
				<div class="sixteen columns">
					<figure class="logo"><img src="img/style1/logo-stone-white.png" alt="Stone." width="143" height="40" /></figure>
				</div>
				
				<!-- Social Icons -->
				<div class="sixteen columns">
					<div class="social-icons">
						<a href="#" title="Facebook"><i class="fa fa-facebook"></i></a>
						<a href="#" title="Twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" title="Instagram"><i class="fa fa-instagram"></i></a>
						<a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a>
						<a href="#" title="Pinterest"><i class="fa fa-pinterest"></i></a>
						<!--
						Other Icons on ( http://www.fontawesome.io/icons/ )
						<a href="#" title="LinkedIn"><i class="fa fa-linkedin"></i></a>
						<a href="#" title="Flickr"><i class="fa fa-flickr"></i></a>
						<a href="#" title="Dribbble"><i class="fa fa-dribbble"></i></a>
						<a href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a>
						<a href="#" title="Github"><i class="fa fa-github"></i></a>
						<a href="#" title="Youtube"><i class="fa fa-youtube"></i></a>
						<a href="#" title="Vimeo"><i class="fa fa-vimeo-square"></i></a>
						-->
					</div>
				</div>
			</div>
		</div><!-- /.container -->
	</section><!-- /#footer -->

	<!-- #Copyright -->
<section id="copyright">		
		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<p>Copyright 2014 Sac Pool Pros. by Sacramento Pool Pros. All Rights Reserved</p>
                    <div style="color:#CCC">
We service the following areas: Sacramento | Elk Grove | Citrus Heights | Fair Oaks | Orangevale | Folsom | Lincoln | Rocklin | Auburn | Grassvalley | Roseville | Woodland | Davis | Cameron Park | Shingle Springs | Rancho Cordova | El Dorado Hills | Natomas | Granite Bay | Loomis | Newcastle | Pocket <br>
We offer professional pool service in the northern California region
</div>
			</div>
		</div><!-- /.container -->
	</section><!-- /#copyright -->

	<!-- Back to Top -->
	<a id="to-top" class="menu" href="#start"><i class="fa fa-angle-up"></i></a>
	
	<!-- jQuery Library
	================================================== -->
	<script src="js/jquery-1.11.0.min.js"></script>
	
	<!-- Smooth Scroll
	================================================== -->
	<script src="js/smooth-scroll.js"></script>

	<!-- Retina Images
	================================================== -->
	<script src="js/retina.min.js"></script>

	<!-- Owl Carousel
	================================================== -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- Stone Actions (You can insert your scripts here)
	================================================== -->
	<script src="js/stone.project.actions.min.js"></script>

</body>
</html>