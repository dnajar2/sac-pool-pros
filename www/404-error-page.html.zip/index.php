<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->	
	<title>Sacramento Pool Service Commercial and residential pool service tile cleaning and pool repairs |Sac Pool Pros</title>
	<meta name="description" itemprop="description" content="Sacramento Pool Service Professionals commercial and residential, pool cleaning, pool repairs, pool construction, pool service and maintenance">

<meta name="keywords" itemprop="keywords" content="Sacramento, Swimming Pool Cleaning, Commercial, Residential, Maintanence, Weekly, Houses, Homes, Acid Washing, Green Cleaning, Pools, Water, Apartments, Hotels, Pubic, Backyard, Private, Concrete, Chlorine, Sanitized, Fiberglass,Natural, Pollution, Environmentally Friendly, clean, porcelain, tile cleaning," />

	<meta name="author" content="Sac Pool Pros">

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!--[if lt IE 9]>
		 <script async src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="http://sacpool.sacpoolpros.netdna-cdn.com/img/favicon.ico">
	<link rel="apple-touch-icon" href="http://sacpool.sacpoolpros.netdna-cdn.com/img/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="http://sacpool.sacpoolpros.netdna-cdn.com/img/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="http://sacpool.sacpoolpros.netdna-cdn.com/img/apple-touch-icon-114x114.png">

	<!-- CSS Template
	================================================== -->
	<link rel="stylesheet" href="css/template-1.css">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<!-- Slideshow Images
	================================================== -->
	<style>
	.bg-img-1 {
		background-image: url('img/slideshow/1.jpg');
	}
	.bg-img-2 {
		background-image: url('img/slideshow/2.jpg');
	}
	.bg-img-3 {
		background-image: url('img/slideshow/3.jpg');
	}
	</style>
</head>
<body>
<?php include("include/analytics.php")?>
	<div class="loading"><div class="over-pattern diagonal opacity20"></div><span>Loading...</span></div>
	
	<div id="back-modal"></div>
	<div id="modal">
		<a href="#" class="modal-close modal-btn"><i class="fa fa-compress"></i></a>
		<div class="modal-nav">
			<a href="#" class="modal-previous modal-btn"><i class="fa fa-angle-left"></i></a>
			<a href="#" class="modal-next modal-btn"><i class="fa fa-angle-right"></i></a>
		</div>
		<div id="modal-inner">
			
			<div class="contentModal personModal" id="person-1">
				<div class="container">
					<div class="row">
						<div class="sixteen columns">
							<h1 class="super-title"><span class="color1">#</span>David Randolph</h1>
							<p class="super-subtitle">Owner</p>
						</div>
					</div>
					<div class="row">
						<div class="six columns">
							<div class="photo">
								<figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/1-340.jpg" alt="Hugo Stonebelt" width="340" height="340" /></figure>						
							</div>
						</div>
						<div class="ten columns">					
							<p class="nomargintop">Sac Pool Pros is family owned and operated with over 10 years in the pool industry David & Jessica strive to keep up to date on the latest swimming pool technology and provide excellent customer service you will not be disappointed when you call Sac Pool Pros! Davids #1 goal is customer satisfaction and going above and beyond for all his customers!  </p>
							<blockquote>
								<p>"Do not go where the path may lead, go instead where there is no path and leave a trail." <span class="autor">Ralph Waldo Emerson</span></p>
							</blockquote>
							<div class="social">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
								<a href="#"><i class="fa fa-dribbble"></i></a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>

			<div class="contentModal personModal" id="person-2">
				<div class="container">
					<div class="row">
						<div class="sixteen columns">
							<h1 class="super-title"><span class="color1">#</span>David Najar</h1>
							<p class="super-subtitle">Co-Owner</p>
						</div>
					</div>
					<div class="row">
						<div class="six columns">
							<div class="photo">
								<figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/2-340.jpg" alt="Kelly Dawsson" width="340" height="340" /></figure>						
							</div>
						</div>
						<div class="ten columns">					
							<p class="nomargintop">David brings 15 years of technical background to Sac Pool Pros, the idea of innovation is part of Sac Pool Pros outlook, bridging the gap between tech and service has been David's primary goal. </p>
							<blockquote>
								<p>"It's not what you look at that matters, it's what you see.
" <span class="autor">Henry David Thoreau</span></p>
							</blockquote>
							<div class="social">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
								<a href="#"><i class="fa fa-dribbble"></i></a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>

			<div class="contentModal personModal" id="person-3">
				<div class="container">
					<div class="row">
						<div class="sixteen columns">
							<h1 class="super-title"><span class="color1">#</span>Jesica Randolph</h1>
							<p class="super-subtitle">Marketing Directorr</p>
						</div>
					</div>
					<div class="row">
						<div class="six columns">
							<div class="photo">
								<figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/3-340.jpg" alt="Matt Davis" width="340" height="340" /></figure>						
							</div>
						</div>
						<div class="ten columns">					
							<p class="nomargintop">Sac Pool Pros is family owned and operated with over 10 years in the pool industry David & Jessica strive to keep up to date on the latest swimming pool technology and provide excellent customer service you will not be disappointed when you call Sac Pool Pros! </p>
							<blockquote>
								<p>"Imagination is more important than knowledge." <span class="autor">Albert Einstein</span></p>
							
							</blockquote>
							<div class="social">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
								<a href="#"><i class="fa fa-dribbble"></i></a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>

			<div class="contentModal personModal" id="person-4">
				<div class="container">
					<div class="row">
						<div class="sixteen columns">
							<h1 class="super-title"><span class="color1">#</span>Noah Randolph</h1>
							<p class="super-subtitle">Son and Future Owner.</p>
						</div>
					</div>
					<div class="row">
						<div class="six columns">
							<div class="photo">
								<figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/4-340.jpg" alt="Noah Randolph" width="340" height="340" /></figure>						
							</div>
						</div>
						<div class="ten columns">					
							<p class="nomargintop">Noah enjoys playing with daddy's toys, from the tractors to the scavators and anything that moves.</p>
							<p>Noah the son of David and Jessica Randolph is the fuel and motivation for owner David Randolph to push the bussines over the adge.</p>
							<div class="social">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
								<a href="#"><i class="fa fa-google-plus"></i></a>
								<a href="#"><i class="fa fa-dribbble"></i></a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
				</div>
			</div>

		</div>
	</div>

	<!-- Start - Used on #to-top click -->
	<div id="start"></div>
	
	<!-- #Slideshow -->
	<section id="slideshow">
		<div id="wrapper">
			<div class="arara-slider">
				<div class="start-button"><a href="#top" id="go-down" class="goto"><i class="fa fa-angle-down"></i></a></div>
				<!-- Slide 1 -->
				<div id="slide-1" class="arara-slide">
					<div class="arara-slide-inner">
						<!-- Using "over-color" and "over-pattern" -->
						<!-- 1. Use <div class="over-color"></div> to put your color over images or sections -->
						<!-- 2. Use <div class="over-pattern"></div> to put your pattern over images or sections. But, see rules bellow: -->
						<!-- 		Rule 1. Add the type class of pattern too. Like this: <div class="over-pattern diagonal"></div> -->
						<!-- 			Types Included: "diagonal", "dots", "vertical" and "horizontal" -->
						<!-- 		Rule 2. Add the opacity class of pattern too. Like this: <div class="over-pattern diagonal opacity50"></div> -->
						<!-- 			Opacity's Included: "opacity20", "opacity30", "opacity40", "opacity50", "opacity60", "opacity70", "opacity80" and "opacity90", -->
						<div class="over-pattern diagonal opacity50"></div><div class="over-color"></div>
						<div class="bg-img bg-img-1"></div>
						<div class="arara-slide-content">
							<!-- Using Animations -->
							<!-- Rule 1. You need declare class="elem-X" | X is the order number (don't repeat number, use sequences from 1 to infinite)  -->
							<!-- Rule 2. Use the class "animation" on each slide element (each div)  -->
							<!-- Rule 3. Declare positions (top left, top right, ccenter, bottom left, bottom right) using classes like this example: <div class="animation top right"> -->
							<!-- Rule 4. Add type, time, delay and initial position (xy) of each animation. Especifications are bellow: -->
							<!-- 		data-type:		Type of animation. Options of easings with examples can be found here http://easings.net/ -->
							<!-- 		data-time:		Duration of animation/transition. Using miliseconds ("1000" = 1 second) -->
							<!-- 		data-delay:		Time to wait until element appears. Using miliseconds too -->
							<!-- 		data-xy:			Initial positions X (vertical) and Y (horizontal). These positions are used on element before the animation -->
							<div class="elem-1 animation top left" data-type="easeOutSine" data-time="200" data-delay="0" data-xy="0, 300">
								<h5>Hello! We are...</h5>
							</div>
							<div class="elem-2 animation ccenter" data-type="easeOutSine" data-time="600" data-delay="600" data-xy="0, -100">
								<div class="vcenter"><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/SPP-Logo.png" alt="Sac Pool Pros" />
							  <h2>Your Pool Experts<span class="color4">.</span></h2><a href="#top" class="link goto"><i class="fa fa-magic"></i>Pool Pros</a> <a href="#services" class="link goto"><i class="fa fa-comment"></i>Pool Services</a></div>
							</div>
							<div class="elem-3 animation bottom hcenter" data-type="easeOutElastic" data-time="3000" data-delay="1500" data-xy="60, 0">
								<h6>Nice to meet you!</h6>
							</div>
							<div class="elem-4 animation top right" data-type="easeOutBounce" data-time="1200" data-delay="300" data-xy="-100, 0">
								<i class="fa fa-globe white"></i>
							</div>
						</div>
					</div>
				</div>

				<!-- Slide 2 -->
				<div id="slide-2" class="arara-slide">
					<div class="arara-slide-inner">
						<div class="over-pattern diagonal opacity50"></div><div class="over-color"></div>
						<div class="bg-img bg-img-2"></div>
						<div class="arara-slide-content">
							<div class="elem-1 animation top right" data-type="easeOutSine" data-time="600" data-delay="600" data-xy="0, 300">
								<h5>Scroll to see...</h5>
							</div>
							<div class="elem-2 animation ccenter" data-type="easeOutSine" data-time="300" data-delay="200" data-xy="0, -100">
								<div class="vcenter"><h1>Our work<span class="color4">.</span></h1><a href="#contact" class="link goto"><i class="fa fa-comment"></i>Let's talk now!</a> <a href="green-pool.php" class="link goto"><i class="fa fa-comment"></i>Green Pools</a> <a href="#services" class="link goto"><i class="fa fa-comment"></i>Pool Services</a></div>
							</div>
							<div class="elem-3 animation bottom hcenter" data-type="easeOutElastic" data-time="1200" data-delay="1500" data-xy="60, 0">
								<h6><a href="#top" class="goto">Click to start!</a></h6>
							</div>
							<div class="elem-4 animation top left" data-type="easeOutBounce" data-time="600" data-delay="0" data-xy="-100, 0">
								<i class="fa fa-arrow-down medium white"></i>
							</div>
						</div>
					</div>
				</div>

				<!-- Slide 3 -->
				<div id="slide-3" class="arara-slide">
					<div class="arara-slide-inner">
						<div class="over-pattern diagonal opacity50"></div><div class="over-color"></div>
						<div class="bg-img bg-img-3"></div>
						<div class="arara-slide-content">
							<div class="elem-1 animation top right" data-type="easeOutSine" data-time="600" data-delay="600" data-xy="0, 300">
								<h5>Call Us at (530) 312-2614</h5>
							</div>
							<div class="elem-2 animation ccenter" data-type="easeOutSine" data-time="300" data-delay="200" data-xy="0, -100">
								<div class="vcenter"><h1>Talk with us<span class="color4">.</span></h1><a href="#contact" class="link goto"><i class="fa fa-envelope-o"></i>Save time</a></div>
							</div>
							<div class="elem-3 animation bottom hcenter" data-type="easeOutElastic" data-time="1200" data-delay="1500" data-xy="60, 0">
								<h6>Swimming Pool Cleaning, Repairing and more...</h6>
							</div>
							<div class="elem-4 animation top left" data-type="easeOutBounce" data-time="600" data-delay="0" data-xy="-100, 0">
								<i class="fa fa-pencil medium white"></i>
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.sl-slider -->
			
			<!-- Arrows -->
			<span class="nav-arrow prev"><i class="fa fa-angle-left"></i></span>
			<span class="nav-arrow next"><i class="fa fa-angle-right"></i></span>
		</div><!-- /.slider -->
		<div class="clear"></div>
	</section><!-- /#slideshow -->

	<div id="top">
		<div class="container">
			<div class="four columns clearfix">
				<figure class="logo"><a href="./"><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/style1/logo-stone.png" alt="Stone" width="143" height="40" /></a></figure>
				<!-- Mobile Menu -->
				<nav id="mobile-top-menu">
					<a href="#" class="mobile-nav-button"><i class="fa fa-bars"></i></a>
					<div id="menu-list"><div id="menu-content"></div></div>
				</nav>
			</div>

			<div class="twelve columns">
				<!-- Main Menu -->
			<?php include("include/topnav.php");?>
	<!-- Don't remove #top-space! -->
	<div id="top-space"></div>
	<!-- Don't remove #top-space! -->

	<!-- #About -->
	<section id="about" class="first-section page">
		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<h1 class="super-title"><span class="color1">#</span>About Us</h1>
				</div>
			</div>

			<div class="row">
				<!-- A little bit about us... -->
				<div class="eight columns">
					<h2 class="title">A little bit about us...</h2>
					<p>Sac Pool Pros has been servicing commercial and residential swimming pools in the greater sacramento area for over 10 years we are the leader in customer satisfaction. Sac Pool Pros offers a variety of swimming pool services from weekly pool maintenance too major repairs and equipment installs we can fix anything on your swimming pool we also offer tile cleaning we can bring your swimming pool tiles back to life if they are covered in calcium build up no problem we use state of the art soda blasting technology to blast all the calcium build up and gunk of your tiles making them shine like they did when they were first installed!! .</p>
				</div>
				<!-- Photo Slider -->
				<div class="eight columns column-space">
					<div id="image-rotator">
						<ul class="bjqs">
							<!-- // You can control pattern style.
										Opacity:	From 'opacity20' to 'opacity90' (20, 30, 40, 50, 60, 70, 80, 90). To set '100' = Remove 'opacity__' class.
										Style:		'dots', 'diagonal', 'vertical' and 'horizontal'
										Examples:
											<div class="over-pattern dots opacity50"></div>
											<div class="over-pattern vertical opacity90"></div>
											<div class="over-pattern horizontal"></div>
							-->
							<li><div class="over-pattern diagonal opacity30"></div><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/about/1.jpg" alt="Photo 1" width="460" height="280" ></li>
							<li><div class="over-pattern diagonal opacity30"></div><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/about/2.jpg" alt="Photo 2" width="460" height="280" ></li>
							<li><div class="over-pattern diagonal opacity30"></div><img src="http://sacpool.sacpoolpros.netdna-cdn.com/img/about/3.jpg" alt="Photo 3" width="460" height="280" ></li>
						</ul>
					</div>
				</div>				
			</div>
		</div><!-- /.container -->

		<!-- Counters / Fun Facts -->
		<div id="counters">
			<div class="container">
				<div class="four columns">
					<div class="counter">
						<span id="counter1" class="number" data-counter-from="150" data-counter-seconds="1" data-counter-to="182">182</span>
						<span class="desc">Completed Projects</span>
					</div>
				</div>
				<div class="four columns">
					<div class="counter">
						<span id="counter2" class="number" data-counter-from="280" data-counter-seconds="2" data-counter-to="305">305</span>
						<span class="desc">Happy Customers</span>
					</div>
				</div>
				<div class="four columns">
					<div class="counter">
						<span id="counter3" class="number" data-counter-from="1240" data-counter-seconds="1" data-counter-to="1267">1267</span>
						<span class="desc">Facebook Likes</span>
					</div>
				</div>
				<div class="four columns">
					<div class="counter">
						<span id="counter4" class="number" data-counter-from="0" data-counter-seconds="2" data-counter-to="13">13</span>
						<span class="desc">Awards Earned</span>
					</div>
				</div>
			</div>
		</div>

		<!-- Our amazing team... -->
		<div id="team">
			<div class="over-pattern diagonal opacity50"></div>

			<div class="container">
				<div class="sixteen columns">
					<h2 class="title white">Our amazing team...</h2>
				</div>
				<!-- Person #1 -->
				<div class="four columns person">
					<a href="#person-1" class="open-modal photo">
						<div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
						<figure>
							<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/1@2x.jpg"	alt="Hugo Stonebelt" width="420" height="420" />
							<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/1.jpg"			alt="Hugo Stonebelt" width="220" height="220" />
						</figure>
					</a>
					<div class="info">
						<h3>David Randolph</h3>
						<h4>Owner</h4>
						<p>David is one of the youngest business owners in the industry with a solid background in swimming pool construction, service &amp; repairs </p>
						<div class="social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-linkedin"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
						</div>
					</div>
				</div>
				<!-- Person #2 -->
				<div class="four columns person">
					<a href="#person-2" class="open-modal photo">
						<div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
						<figure>
							<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/2@2x.jpg"	alt="Kelly Dawsson" width="420" height="420" />
							<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/2.jpg"			alt="Kelly Dawsson" width="220" height="220" />
						</figure>
					</a>
					<div class="info">
						<h3>David Najar</h3>
						<h4>Co-Owner</h4>
						<p>David has a BS in Computer Science from Cal Poly, David is the technical brains of the company.</p>
						<div class="social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-linkedin"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
						</div>
					</div>
				</div>
				<!-- Person #3 -->
				<div class="four columns person">
					<a href="#person-3" class="open-modal photo">
						<div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
						<figure>
							<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/3@2x.jpg"	alt="Matt Davis" width="420" height="420" />
							<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/3.jpg"			alt="Matt Davis" width="220" height="220" />
						</figure>
					</a>
					<div class="info">
						<h3>Jessica Randolph</h3>
						<h4>Marketing Director</h4>
						<p>Jessica our marketing director has a full plate making sure we do our jobs right.</p>
						<div class="social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-linkedin"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
						</div>
					</div>
				</div>
				<!-- Person #4 -->
				<div class="four columns person">
					<a href="#person-4" class="open-modal photo">
						<div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
						<figure>
							<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/4@2x.jpg"	alt="Noah Randolph" width="420" height="420" />
							<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/team/4.jpg"			alt="Noah Randolph" width="220" height="220" />
						</figure>
					</a>
					<div class="info">
						<h3>Noah Randolph</h3>
						<h4>Son and Future Owner.</h4>
						<p>Noah enjoys playing with daddy's toys, he has a mean arm when it comes to trowing things. .</p>
						<div class="social">
							<a href="#"><i class="fa fa-facebook"></i></a>
							<a href="#"><i class="fa fa-twitter"></i></a>
							<a href="#"><i class="fa fa-linkedin"></i></a>
							<a href="#"><i class="fa fa-google-plus"></i></a>
							<a href="#"><i class="fa fa-dribbble"></i></a>
						</div>
					</div>
				</div>
			</div><!-- /.container -->
		</div><!-- /#team -->
		
		<div class="container margintop">
			<!-- Why choose us? -->
			<div id="why-choose" class="eight columns">
				<h2 class="title"><span>Why choose us?</span></h2>
				<ul class="accordion">
					<li>
						<a href="#"><i class="fa fa-plus"></i> Quality</a>
						<p class="description">Sac Pool Pros offers you the highest level of quality in any of its services, your pool will receive the level of attention it deserves.
Quality is our number one priority because we understand how important your pool is, our job is to ensure your pool is properly maintained and that is safe for you to use. </p>
<p class="description"> 
			</p>
					</li>
					<li>
						<a href="#"><i class="fa fa-plus"></i> Responsible</a>
						<p class="description">At Sac Pool Pros we take our job serous, we know the importance of maintaining a responsible and professional appearance to you the customer, what we say we do and we stand by that.  
						</p>
					</li>
					<li>
						<a href="#"><i class="fa fa-plus"></i> Reliable</a>
						<p class="description">At Sac Pool Pros we have the most reliable staff in the Sacramento our team has the best of the best in the pool industry, we ensure our staff is adequately trained to handle your pool we will not send just anyone to service one of your most valuable assets. 
						</p>
					</li>
					<li>
						<a href="#"><i class="fa fa-plus"></i> Reasonable</a>
						<p class="description">At Sac Pool Pros we have a firm belief in being reasonable, we stand by the golden rule and we treat you our customer as we would like to be treated, we don’t have over charges or hidden fees or fine print, we will stand by our pricing and our quotes.
						</p>
					</li>
				</ul>
			</div>
			
			<!-- What we do better? -->
			<div id="we-do-better" class="eight columns column-space">
				<h2 class="title"><span>What we do better?</span></h2>
				<ul class="skills">
					<li><div class="over-pattern diagonal opacity30"></div>
					<span class="percentage wait" data-value="95"></span><span class="text">Green Pool Cleaning - 95%</span>&nbsp;</li>
					<li><div class="over-pattern diagonal opacity30"></div>
					<span class="percentage wait" data-value="90"></span><span class="text">Tile Cleaning - 90%</span>&nbsp;</li>
					<li><div class="over-pattern diagonal opacity30"></div><span class="percentage wait" data-value="100"></span><span class="text">Repairs &amp; Replacements - 100%</span>&nbsp;</li>
					<li><div class="over-pattern diagonal opacity30"></div><span class="percentage wait" data-value="100"></span><span class="text">weekly pool service - 100%</span>&nbsp;</li>
				</ul>
			</div>
		</div><!-- /.container -->

		<!-- Be one of us! -->
		<div id="jobs">
			<div class="icons">
				<i class="fa fa-bullhorn mini"></i>
				<i class="fa fa-bullhorn small"></i>
				<i class="fa fa-bullhorn medium"></i>
				<i class="fa fa-bullhorn large"></i>
				<i class="fa fa-bullhorn xlarge"></i>
			</div>
			<div class="container">
				<div class="sixteen columns">
					<h2 class="title center"><span>We Think We Are The Best</span></h2>
					<p class="large center">We think we are the best because you the client said so, Great people work here to develop the best solutions for you. Each member of our team has its own function, and without doubt, makes the best possible way! </p>
					<div class="center"><!--<a id="show-jobs" href="#" class="btn color1"><i class="fa fa-search"></i> See jobs</a>--></div>
				</div>
			</div>
		</div><!-- /#jobs -->
	</section><!-- /#about -->

	<hr class="dotted-2">

	<!-- #services -->
	<section id="services" class="page">
		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<h1 class="super-title"><span class="color1">#</span>Services</h1>
					<p class="super-subtitle">From "A" to "Z" on <span class="color1">swimming pool everything</span>! Knowledge, style and good communication.</p>
				</div>
			</div>
			<div class="row nomarginall">
				<div class="sixteen columns">
					<!-- What we can offer to you? -->
					<h2 class="title">What we can offer to you?</h2>
				</div>
				<div id="service" class="sixteen columns">
					<!-- #service 1 -->
					<div class="one-third column alpha">
						<div class="service alpha">
							<div class="service-icon">
								<i class="fa fa-rocket"></i>
								<i class="fa fa-rocket shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Green Pool Cleaning</h2>
								<p>Bring your swimming pool back to life Sac Pool Pros will drain and chlorine wash your swimming
pool making it look brand new again!</p>
							</div>
						</div>
					</div>
					<!-- #service 2 -->
					<div class="one-third column">
						<div class="service">
							<div class="service-icon">
								<i class="fa fa-heart"></i>
								<i class="fa fa-heart shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Weekly Service</h2>
								<p>We provide you with the highest level on quality swimming pool service at affordable rates</p>
							</div>
						</div>
					</div>	
					<!-- #service 3 -->
					<div class="one-third column omega">
						<div class="service">
							<div class="service-icon">
								<i class="fa fa-picture-o"></i>
								<i class="fa fa-picture-o shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Tile Cleaning</h2>
								<p>Is your swimming pool tile full of white calcium build up or gunk?
At Sac Pool Pros we can restore your swimming pool tile to look like the first day it was installed don't spend thousands replacing your tile let us clean it for you! </p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="sixteen columns">
					<!-- #service 4 -->
					<div class="one-third column alpha">
						<div class="service">
							<div class="service-icon">
								<i class="fa fa-group"></i>
								<i class="fa fa-group shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Repairs</h2>
								<p>We can repair anything on a built in swimming pool from pumps and filters to big remodels if you can think it we can do it! </p>
							</div>
						</div>
					</div>
					<!-- #service 5 -->
					<div class="one-third column">
						<div class="service">
							<div class="service-icon">
								<i class="fa fa-magic"></i>
								<i class="fa fa-magic shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Solar Power</h2>
								<p>At Sac Pool Pros we offer quality solar installs to heat your swimming pool at a fraction of what the big companies are charging using the same grade materials they use! </p>
							</div>
						</div>
					</div>
					<!-- #service 6 -->
					<div class="one-third column omega">
						<div class="service">
							<div class="service-icon">
								<i class="fa fa-camera"></i>
								<i class="fa fa-camera shadow-icon"></i>
							</div>
							<div class="service-info">
								<h2>Satisfaction</h2>
								<p>We are certain you will be satisfied with our service, and will stand by any guaranty offered by our team.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Testimonials Carousel -->
		<div id="testimonials">
			<div class="over-color"></div><div class="over-pattern vertical opacity50"></div>
			<div class="container">
				<div class="row">
					<!-- Testimonial #1 -->
					<div class="sixteen columns">
						<div class="carousel clearfix">
							<div class="icon"><i class="fa fa-quote-left"></i></div>
							<div class="wrapper">
								<div class="wrapper-inner">
									<ul class="testimonial">
										<li>
											<blockquote>
												<p>"Amazing staff, I really liked all them seem young but have tons of experiance. Thanks for all the support given to us, Sac Pool Pros!"</p>
												<p class="author">Rudolf Dassler</p>
												<p class="company">Rocklin</p>
											</blockquote>
										</li>
										<li>
											<blockquote>
												<p>"Some companies promise quality and speed. They just do it without a lot of promises. We left our satisfaction recorded. Thank you!"</p>
												<p class="author">Adolf Dassler</p>
												<p class="company">Elk Grove</p>
											</blockquote>
										</li>
										<li>
											<blockquote>
												<p>"Ever since we started with Sac Pool Pros, all of our expectations have been met."</p>
												<p class="author">Phillips Heusen</p>
												<p class="company">Folsom.</p>
											</blockquote>
										</li>
									</ul>
								</div>
							</div>
							<nav class="arrows">
								<a href="#" class="arrow arrow-left"><i class="fa fa-angle-left"></i></a>
								<a href="#" class="arrow arrow-right"><i class="fa fa-angle-right"></i></a>
							</nav>
							<nav class="bullets">
								<a href="#" class="bullet active" id="bullet-1"></a>
								<a href="#" class="bullet" id="bullet-2"></a>
								<a href="#" class="bullet" id="bullet-3"></a>
							</nav>
						</div>
					</div>
				</div><!-- /.row -->
			</div><!-- /.container -->
		</div><!-- /#testimonials -->
	</section><!-- /#services -->
	
	<!-- #Portfolio -->
	<section id="portfolio" class="page">
		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<h1 class="super-title"><span class="color1">#</span>Portfolio</h1>
					<p class="super-subtitle">Here, we have samples of our <span class="color1">powerful</span> service.</p>
				</div>
			</div>

			<div class="row">
				<!-- Isotope Portfolio -->
				<section id="work-gallery">
					<section id="options" class="clearfix">
						<div class="option-combo">
							<ul id="filter" class="option-set clearfix" data-option-key="filter">
								<li><a href="#show-all" data-option-value="*" class="selected">All</a></li>
								<li><a href="#web-development" data-option-value=".web-development">Pool Services</a></li>
								<li><a href="#video" data-option-value=".video">Video</a></li>
								<li><a href="#print-design" data-option-value=".print-design">Tile Cleaning</a></li>
								<li><a href="#branding" data-option-value=".branding">Repairs</a></li>
								<li><a href="#illustration" data-option-value=".illustration">Green Pool Transformation</a></li>
								<li><a href="#ui" data-option-value=".ui">Equipment Installs</a></li>
								<li><a href="#solar" data-option-value=".solar">Solar</a></li>
							</ul>
						</div>
					</section>
					<div id="container" class="gallery super-list variable-sizes clearfix">
						<!-- Video Support -->
						<div class="video feature">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item6-1@2x.jpg"	alt="Video 1" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item6-1.jpg"			alt="Video 1" width="300" height="225" />
								<div class="mask">
									<div class="options">
                                    <a class="lightbox" data-group="work" href="//www.youtube-nocookie.com/embed/zIwgWe0kXTE?rel=0" data-caption="Pool Tile Cleaning - Video" data-video="[800 454]" data-autoplay="1"><i class="fa fa-play"></i></a>
										<a href="//www.youtube-nocookie.com/embed/zIwgWe0kXTE?rel=0" target="_blank"><i class="fa fa-link"></i></a> 
									</div>
								</div>
								<div class="content">
									<h3>Pool Tile Cleaning</h3>
									<p>You Tube Video</p>
								</div>
							</div>
						</div>
						<!-- Work #1 -->
						<div class="web-development branding">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-1@2x.jpg"	alt="Work 1" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-1.jpg"			alt="Work 1" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item1-1.jpg" data-caption="Work 1 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-service.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Any Pool Issue</h3>
									<p>Full Pool Service</p>
								</div>
							</div>
						</div>
						<!-- Work #2 -->
						<div class="print-design">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item2-1@2x.jpg"	alt="Work 2" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item2-1.jpg"			alt="Work 2" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item2-1.jpg" data-caption="Work 2 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-tile-cleaning.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Pool Tile Cleaning</h3>
									<p>Pool tile restoration</p>
								</div>
							</div>
						</div>
						<!-- Work #3 -->
						<div class="branding">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item3-1@2x.jpg"	alt="Work 3" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item3-1.jpg"			alt="Work 3" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item3-1.jpg" data-caption="Work 3 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-repairs.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Pool Lights</h3>
									<p>pool equipment repairs</p>
								</div>
							</div>
						</div>
						<!-- Work #4 -->
						<div class="ui web-development feature">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item4-1@2x.jpg"	alt="Work 4" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item4-1.jpg"			alt="Work 4" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item4-1.jpg" data-caption="Work 4 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-service.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Weekly Service</h3>
									<p>We have diffrent plans to choose from</p>
								</div>
							</div>
						</div>
						<!-- Work #5 -->
						<div class="illustration branding feature">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item5-1@2x.jpg"	alt="Work 5" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item5-1.jpg"			alt="Work 5" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item5-1.jpg" data-caption="Work 5 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-service.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Pool Clean Up</h3>
									<p>We can do any pool clean up</p>
								</div>
							</div>
						</div>
						<!-- Work #6 -->
						<div class="ui print-design">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item6-1@2x.jpg"	alt="Work 6" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item6-1.jpg"			alt="Work 6" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item6-1.jpg" data-caption="Work 6 - Lightbox Example"><i class="fa fa-expand"></i></a>
										<a href="pool-service.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Build up</h3>
									<p>Remove that ugly build up</p>
								</div>
							</div>
						</div>
                        <!-- Pool Construction service -->
                        <div class="web-development branding">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-3@2x.jpg"	alt="Work 6" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-3.jpg"			alt="Work 6" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item1-3.jpg" data-caption="Pool Construction Service"><i class="fa fa-expand"></i></a>
										<a href="pool-construction.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Pool Construction Service</h3>
									<p>Best In California</p>
								</div>
							</div>
						</div>
                        
                        <!-- pool solar -->
                        <div class="web-development branding">
							<div class="work"><div class="over-pattern diagonal opacity30"></div><div class="over-color"></div>
								<img class="smallscreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-3@2x.jpg"	alt="Work 6" width="420" height="315" />
								<img class="largescreen" src="http://sacpool.sacpoolpros.netdna-cdn.com/img/portfolio/thumbs/item1-3.jpg"			alt="Solar" width="300" height="225" />
								<div class="mask">
									<div class="options">
										<a class="lightbox" data-group="work" href="img/portfolio/item1-3.jpg" data-caption="Pool Construction Service"><i class="fa fa-expand"></i></a>
										<a href="pool-construction.php"><i class="fa fa-link"></i></a>
									</div>
								</div>
								<div class="content">
									<h3>Solar Systems</h3>
									<p>Best In California</p>
								</div>
							</div>
						</div>
                        
					</div>
				</section>
				<!-- / Isotope Example -->
			</div><!-- /.row -->

			<!-- Featured clients... -->
			<div class="row">
				<div class="sixteen columns">				
					<h2 class="title">Featured clients...</h2>
				</div>
			</div>
			<div id="clients">
				<div class="sixteen columns">
					<div id="owl-clients" class="owl-carousel">
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/AN4751~1.JPG.jpg" alt="Folsom Swimming Pool" width="400" height="300" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Antonios Pools Slideshow 054.jpg" alt="Roseville Swimming Pool" width="32" height="32" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/IMG_1395.JPG" alt="El Dorado Hiils Swimming Pool" width="400" height="300" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Granite Bay.jpg" alt="Granite Bay Swimming Pool" width="32" height="32"	/></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Folsom Pool.jpg" alt="Folsom Swimming Pool" width="32" height="32" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Roseville-pool.jpg" alt="Roseville Swimming Pool"						width="2048" height="1536" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Rocklin.jpg" alt="Rocklin Pool" width="400" height="320" /></figure></div>
						<div class="item"><figure><img src="http://sacpool.sacpoolpros.netdna-cdn.com/images/Davis-pool.JPG" alt="Davis Swimming Pool" width="400" height="300"/></figure></div>
					</div>
				</div>				
			</div><!-- /#clients -->
			<div class="clear"></div>
		</div><!-- /.container -->
	</section><!-- /#portfolio -->

	<!-- #Contact -->
	<section id="contact" class="page">
		<div class="container">
			<div class="row">
				<div class="sixteen columns">
					<h1 class="super-title"><span class="color1">#</span>Contact Us</h1>
					<p class="super-subtitle">Feel free to contact us if you have <span class="color1">something to say</span>!</p>
				</div>
			</div>
		</div>

		<!-- Get in touch -->
		<form id="contactForm" class="form-block">
			<div class="container">
				<div class="row">
					<div class="sixteen columns">
						<h2 class="title">Get in touch!</h2>
					</div>
				</div>
				
				<div class="row">
					<!-- Contact Form -->
					<div class="ten columns">
						<div class="fields">
							<div class="row">
								<div class="five columns alpha">
									<label for="contact-name">Name</label>
									<input type="text" id="contact-name" name="contact-name" />
								</div>
								<div class="five columns omega">
									<label for="contact-email">Email</label>
									<input type="text" id="contact-email" name="contact-email" />
								</div>
							</div>
						</div>
						<div class="fields">
							<div class="row">
								<div class="five columns alpha">
									<label for="contact-subject">Subject</label>
									<input type="text" id="contact-subject" name="contact-subject" />
								</div>
								<div class="five columns omega">
									<label for="contact-phone">Phone</label>
									<input type="text" id="contact-phone" name="contact-phone" class="phone" maxlength="14" />
								</div>
							</div>
						</div>
						<div class="fields">
							<div class="row">
								<label for="contact-message">Message</label>
								<textarea id="contact-message" name="contact-message" cols="1" rows="1"></textarea>
							</div>
						</div>
						<div class="fields">
							<div class="row">
								<input type="submit" class="btn color2" name="contact-send" value="Submit" />
							</div>
						</div>
						<div class="row">
							<div id="returnContact" class="return-message wait">Please, wait...</div>
						</div>
					</div>
					
					<!-- Contact Info -->
					<div class="contact-info six columns">
						<p class="large">
							<span class="bold color1">Sac Pool Pros</span></p>
						<p>6241 Turner Rd<br>
							Sacramento, CA 95829
					      <br>
						</p>
						<p class="large">
							<span class="bold color1">E:</span> info@sacpoolpros.com<br/>
							<span class="bold color1">P:</span>(530) 312-2614
						</p>
					</div>
				</div><!-- /.row -->
			</div><!-- /.container -->
			<hr class="double">
		</form><!-- /.form-block -->

		<!-- Map -->
		<!-- The element that will contain our Google Map. This is used in both the Javascript and CSS above. -->
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3121.9929284310433!2d-121.37070858466102!3d38.51087397963213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x809ac48920331819%3A0x9bd15cbb43d7147d!2s6421+Turner+Rd%2C+Sacramento%2C+CA+95829!5e0!3m2!1sen!2sus!4v1456202547198" width=100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>	
	</section><!-- /#contact -->

	<!-- #Footer -->
	
	<?php include("include/footer.php")?><!-- /#copyright -->

	<!-- Back to Top -->
	<a id="to-top" class="menu" href="#start"><i class="fa fa-angle-up"></i></a>
	
	<!-- jQuery Library
	================================================== -->
	<script src="js/jquery-1.11.0.min.js"></script>
	<script src="js/jquery.easing.1.3.min.js"></script>

	<!-- Smooth Scroll
	================================================== -->
	<script src="js/smooth-scroll.js"></script>

	<!-- Retina Images
	================================================== -->
	<script src="js/retina.min.js"></script>

	<!-- Responsive Arara Slider
	================================================== -->
	<script src="js/arara-slider.min.js"></script>

	<!-- Basic Slider
	================================================== -->
	<script src="js/jquery.basicslider-1.3.min.js"></script>

	<!-- Responsive Lightbox
	================================================== -->
	<script src="js/jquery.lightbox.min.js"></script>

	<!-- Owl Carousel
	================================================== -->
	<script src="js/owl.carousel.min.js"></script>

	<!-- jQuery Validate Plugin
	================================================== -->
	<script src="js/jquery.validate.min.js"></script>


	<!-- Isotope Plugin
	================================================== -->
	<script src="js/jquery.isotope.min.js"></script>

	<!-- Stone Actions (You can insert your scripts here)
	================================================== -->
	<script src="js/stone.actions.min.js"></script>

</body>
</html>